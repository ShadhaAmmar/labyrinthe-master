import java.util.ArrayList;
import java.util.List;

public class Noeud {

    public int x,y;
    public char lettre;
    public enum TypeNoeud{
        passante,
        bloquante,
        depart,
        arrivee,
    }
    public TypeNoeud typeNoeud;
    public List<Noeud> voisins;
   public Noeud(int x, int y, char lettre, TypeNoeud typeNoeud) {
       this.x = x;
       this.y = y;
       this.lettre = lettre;
       this.typeNoeud = typeNoeud;
       this.voisins = new ArrayList<>();
   }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public char getLettre() {
        return lettre;
    }

    public void setLettre(char lettre) {
        this.lettre = lettre;
    }

    public TypeNoeud getTypeNoeud() {
        return typeNoeud;
    }

    public void setTypeNoeud(TypeNoeud typeNoeud) {
        this.typeNoeud = typeNoeud;
    }

    public List<Noeud> getVoisins() {
        return voisins;
    }

    public void setVoisins(List<Noeud> voisins) {
        this.voisins = voisins;
    }


    public void ajouterVoisin(Noeud voisin) {
        this.voisins.add(voisin);
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ",'" + lettre + "', " + typeNoeud.toString() + ")";
    }

    private int distance = Integer.MAX_VALUE; // Distance à partir du point de départ
    private Noeud predecesseur = null; // Prédécesseur dans le chemin le plus court

    // Ajouter des getters et setters pour ces nouveaux attributs
    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public Noeud getPredecesseur() {
        return predecesseur;
    }

    public void setPredecesseur(Noeud predecesseur) {
        this.predecesseur = predecesseur;
    }
}

